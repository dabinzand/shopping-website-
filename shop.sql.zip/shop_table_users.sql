
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(2, 'amen', 'amen@gmail.com', NULL, '$2y$10$XfCO3nJkaK14HB2o0nO7jOKSU8vZK1MANrxIPHHMpVHK/8JUKg4zW', NULL, '2021-04-20 12:31:15', '2021-04-20 12:31:15'),
(3, 'dabin', 'dabenzandi@gmail.com', NULL, '$2y$10$x.sm/9r83Me/85NClAboregGbNtUvbE5ZGDZyTPtAJ57RT4phQIiG', NULL, '2021-04-20 10:51:13', '2021-04-20 10:51:13');
