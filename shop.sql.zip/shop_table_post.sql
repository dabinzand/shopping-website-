
-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sizes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`sizes`)),
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `userid` bigint(20) UNSIGNED NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `title`, `sizes`, `price`, `image`, `userid`, `details`) VALUES
(8, 'Grey Super Skinny', '[\"XS\",\"S\",\"M\",\"L\",\"XL\",\"2XL\"]', '18.000', '2.jpg', 5, 'This is Kurdish Model'),
(9, 'shirt', '[\"XS\",\"S\",\"M\",\"L\",\"XL\",\"2XL\"]', '20.000', '3.jpg', 5, 'This is Kurdish Model'),
(10, 'Ecru Set ', '[\"XS\",\"S\",\"M\",\"L\",\"XL\",\"2XL\"]', '12.000', '4.jpg', 3, 'This is Kurdish Model'),
(11, 'Navy Shorts ', '[\"XS\",\"S\",\"M\",\"L\",\"XL\",\"2XL\"]', '22.000', '5.jpg', 5, 'This is Kurdish Model'),
(12, 'Green Thin Jumper ', '[\"XS\",\"S\",\"M\",\"L\",\"XL\",\"2XL\"]', '12.000', '6.jpg', 3, 'This is Kurdish Model'),
(13, 'Shirt', '[\"XS\",\"S\",\"M\",\"L\",\"XL\",\"2XL\"]', '22.000', '7.jpg', 5, ''),
(15, 'Turquoise Shorts', '[\"XS\",\"S\",\"M\",\"L\",\"XL\",\"2XL\"]', '12.000', '9.jpg', 3, ''),
(16, 'Blue Shirt', '[\"XS\",\"S\",\"M\",\"L\",\"XL\",\"2XL\"]', '20.000', '10.jpg', 5, ''),
(17, 'Black Null ', '[\"XS\",\"S\",\"M\",\"L\",\"XL\",\"2XL\"]', '30.000', '11.jpg', 2, ''),
(18, 'Black Skirt ', '[\"XS\",\"S\",\"M\",\"L\",\"XL\",\"2XL\"]', '30.000', '12.jpg', 5, ''),
(19, 'Red T-shirt ', '[\"XS\",\"S\",\"M\",\"L\",\"XL\",\"2XL\"]', '23.000', '13.jpg', 2, '');
