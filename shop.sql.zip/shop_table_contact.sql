
-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `title`, `desc`, `created_at`, `updated_at`) VALUES
(1, 'mr dabin', 'dfghjk', '2021-04-19 08:41:35', '2021-04-19 08:41:35'),
(2, 'mr dabin', 'hvhkjsd', '2021-06-11 10:26:16', '2021-06-11 10:26:16');
