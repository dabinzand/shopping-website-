
-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `guest_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `size` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`size`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `guest_id`, `post_id`, `size`, `created_at`, `updated_at`) VALUES
(1, '16857005851226046276', 9, '[\"XS\",\"S\",\"M\"]', '2020-05-06 11:36:53', '2020-05-06 11:36:53'),
(2, '1276786001472786588', 19, '[\"XS\"]', '2021-04-19 08:48:15', '2021-04-19 08:48:15'),
(3, '1276786001472786588', 14, '[\"M\"]', '2021-04-19 09:35:38', '2021-04-19 09:35:38'),
(4, '1276786001472786588', 14, '[\"M\"]', '2021-04-19 10:16:46', '2021-04-19 10:16:46'),
(5, '1276786001472786588', 19, '[\"M\",\"L\"]', '2021-04-20 08:53:31', '2021-04-20 08:53:31'),
(6, '1276786001472786588', 17, '[\"M\"]', '2021-04-20 08:54:25', '2021-04-20 08:54:25'),
(7, '1276786001472786588', 15, '[\"M\"]', '2021-04-20 09:48:51', '2021-04-20 09:48:51'),
(8, '1276786001472786588', 14, '[\"M\",\"L\"]', '2021-04-21 12:16:12', '2021-04-21 12:16:12');
